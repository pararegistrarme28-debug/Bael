# Nexus Core Pro

Plataforma segura React + Vite + Express lista para producción.

## Stack
- React 19
- Vite
- Express
- JWT Auth
- Helmet
- Rate Limit
- Docker
- TailwindCSS

## Desarrollo

```bash
npm install
npm run dev
```

## Producción

```bash
docker build -t nexus-core .
docker run -p 3000:3000 nexus-core
```

## Variables

Copia `.env.example` a `.env`