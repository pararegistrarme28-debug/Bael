import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

const app = express();

app.use(express.json());
app.use(helmet());
app.use(cors());

app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
}));

const JWT_SECRET = process.env.JWT_SECRET || "secret";

app.get("/api/health", (_, res) => {
  res.json({ status: "ok" });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  if (
    username !== process.env.ADMIN_USER ||
    password !== process.env.ADMIN_PASSWORD
  ) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const token = jwt.sign({ username }, JWT_SECRET, {
    expiresIn: "12h"
  });

  return res.json({ token });
});

app.listen(process.env.PORT || 3000, () => {
  console.log("Nexus Core Pro online");
});