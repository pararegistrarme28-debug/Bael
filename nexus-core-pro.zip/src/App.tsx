export default function App() {
  return (
    <main style={{
      minHeight: "100vh",
      background: "#050505",
      color: "white",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontFamily: "sans-serif"
    }}>
      <div>
        <h1>Nexus Core Pro</h1>
        <p>Secure production build ready.</p>
      </div>
    </main>
  );
}